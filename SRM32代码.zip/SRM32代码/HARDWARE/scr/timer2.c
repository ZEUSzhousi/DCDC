#include "adc.h"
#include "main.h"         
#include "delay.h"        
#include "timer.h"    
#include "timer2.h"
#include "stm32f10x.h"    
#include "stm32f10x_it.h" 

void TIM2_ENABLE(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;            //����һ�����ö�ʱ���ı���
	NVIC_InitTypeDef NVIC_InitStructure;                          //����һ�������жϵı���
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);               //�����ж��������飺��2�� �������ȼ���0 1 2 3 �����ȼ���0 1 2 3		
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);           //ʹ��TIM2ʱ��	
	TIM_DeInit(TIM2);                                             //��ʱ��2�Ĵ����ָ�Ĭ��ֵ	
	TIM_TimeBaseInitStructure.TIM_Period = 10-1; 	          //�����Զ���װ��ֵ60000-1
	TIM_TimeBaseInitStructure.TIM_Prescaler=36000-1;              //���ö�ʱ��Ԥ��Ƶ��
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;     //1��Ƶ
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);            //����TIM2
	
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);                    //�������жϱ�־λ
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);                      //ʹ��TIM2����ж�    
	TIM_Cmd(TIM2,ENABLE);                                         //��TIM2                          
	
	NVIC_InitStructure.NVIC_IRQChannel=TIM2_IRQn;                 //����TIM2�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;       //��ռ���ȼ�2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;              //�����ȼ�1
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;                 //�ж�ͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);                               //�����ж�
}
extern __IO uint16_t ADC_ConvertedValue[4];
float ADC_ConvertedValueLocal; 
float ADC_ConvertedValueLoca2;
float ADC_ConvertedValueLoca3; 
float ADC_ConvertedValueLoca4;

void TIM2_IRQHandler(void)
{	
	static u16 adc_count=0;

	static float dcinv_out=0,dcini_out=0;
	static float dcoutv_out=0,dcouti_out=0;
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		adc_count++;
		//��ѹ�������
		dcinv_out+=(float) ADC_ConvertedValue[0]/4096*3.277; 
		dcini_out+=(float) ADC_ConvertedValue[1]/4096*3.277; 
		dcoutv_out+=(float) ADC_ConvertedValue[2]/4096*3.277; 
		dcouti_out+=(float) ADC_ConvertedValue[3]/4096*3.277; 
		if(adc_count>=200)
		{
			adc_count=0;
			DCIN_V=dcinv_out/200*VDCIN_Ratio; 	
			DCIN_I=dcini_out/200; 
      if(DCIN_I>=2.50f)DCIN_I=DCIN_I-2.50f;
      else DCIN_I=2.50f-DCIN_I;		
      DCIN_I=DCIN_I*IDCIN_Ratio;
			
			DCOUT_V=dcoutv_out/200*VDCOUT_Ratio; 	
			DCOUT_I=dcouti_out/200; 	
      if(DCOUT_I>=2.50f)DCOUT_I=DCOUT_I-2.50f;
      else DCOUT_I=2.50f-DCOUT_I;		
      DCOUT_I=DCOUT_I*IDCOUT_Ratio;		
			
			DCIN_P=DCIN_V*DCIN_I;
			DCOUT_P=DCOUT_V*DCOUT_I;
			dcinv_out=0;dcini_out=0;dcoutv_out=0;dcouti_out=0;
		}
				
		if(work_mode==1&&protect_status==0)
		{
			if(work_status==0)//��ѹ��·
			{
//				if(ADC_ConvertedValue[0]<((1.0524*Target_V-0.5676)/3.3*4096/V_xishu))buck_pwm+=1;
//				else if(ADC_ConvertedValue[0]>((1.0524*Target_V-0.5676)/3.3*4096/V_xishu))buck_pwm-=1;
//				else buck_pwm=buck_pwm;
				if(ADC_ConvertedValue[0]<(Target_V/VDCIN_Ratio/3.277*4096))
				{
					if(dc_pwm<3599)dc_pwm+=1;
					else dc_pwm=3599;
				}
				else if(ADC_ConvertedValue[0]>(Target_V/VDCIN_Ratio/3.277*4096))
				{
					if(dc_pwm>=1)dc_pwm-=1;
					else dc_pwm=0;
				}
				else dc_pwm=dc_pwm;				
				set_pwm(TIM1,1,dc_pwm,3599);						
      }
			else if(work_status==1)//������·
			{
//				if(ADC_ConvertedValue[0]<((1.0524*Target_V-0.5676)/3.3*4096/V_xishu))buck_pwm+=1;
//				else if(ADC_ConvertedValue[0]>((1.0524*Target_V-0.5676)/3.3*4096/V_xishu))buck_pwm-=1;
//				else buck_pwm=buck_pwm;
				if(ADC_ConvertedValue[3]<(3124+Target_I/IDCOUT_Ratio/3.277*4096))				
				{
					if(dc_pwm<3599)dc_pwm+=1;
					else dc_pwm=3599;
				}
				else if(ADC_ConvertedValue[3]>(3124+Target_I/IDCOUT_Ratio/3.277*4096))
				{
					if(dc_pwm>=1)dc_pwm-=1;
					else dc_pwm=0;
				}
				else dc_pwm=dc_pwm;
				set_pwm(TIM1,1,dc_pwm,3599);								
			}
		}
		else if(work_mode==0&&protect_status==0)
		{
			dc_pwm=0;
			set_pwm(TIM1,1,dc_pwm,1000);		
		}
		else if(protect_status==1)
		{
			dc_pwm=0;
			set_pwm(TIM1,1,dc_pwm,1000);		
		}
  }
  TIM_ClearITPendingBit(TIM2, TIM_IT_Update);          //���TIM2����жϱ�־ 	
}

