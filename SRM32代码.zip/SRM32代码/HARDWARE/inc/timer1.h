/*-------------------------------------------------*/
/*            ��γ����STM32ϵ�п�����              */
/*-------------------------------------------------*/
/*                                                 */
/*            ʵ�ֶ�ʱ��1���ܵ�ͷ�ļ�              */
/*                                                 */
/*-------------------------------------------------*/

#ifndef _TIMER1_H
#define _TIMER1_H
extern float ADC_ConvertedValueLocal; 
extern float ADC_ConvertedValueLoca2;
void TIM1_Time_Init(u16 arr,u16 psc);

#endif
